import logo from './logo.svg';
import './App.css';
import './bootstrap.css'
import WelcomeComponent from './Student/Welcome/WelcomeComponent';


function App() {
  return (
    <div className="App">
      <header className="Student">
      <WelcomeComponent></WelcomeComponent>
      </header>
    </div>
  );
}

export default App;
