
class uploadComponent {
        constructor(props){
            this.state={
                image:null
            }
        }

        handleUpload(){

                    console.log('in Handle upload')
                    return true
        }

}

export default new uploadComponent()